# Terraform Module - Data Landing Zone Stamp

This repository contains secure-by-default and complient-by-design Terraform module for the Data Landing Zone stamp.
