<!-- BEGIN_TF_DOCS -->
# Terraform Module - Data Landing Zone Stamp

This repository contains secure-by-default and compliant-by-design Terraform module for the Data Landing Zone stamp.

## Versioning and Tagging Strategy

This repository uses semantic versioning with moving major version tags. For detailed information about how versions are managed and consumed, see:

**[SOP: Stamp Module Versioning and Tagging Strategy](https://github.com/EnterpriseData-and-AI/platform-architecture/blob/main/docs/SOPs/SOP-stamp-module-versioning-and-tagging.md)**

Key points:
- Specific version tags (e.g., `v1.X.Y`) are immutable releases
- Moving major version tags (e.g., `v1`) always point to the most recent patch version
- The `cdp-edai-rollout` repository references these moving tags for automatic patch updates
- Upgrade major versions by updating the configuration in `cdp-edai-rollout`

## Documentation
<!-- markdownlint-disable MD033 -->

## Requirements

The following requirements are needed by this module:

- <a name="requirement_terraform"></a> [terraform](#requirement\_terraform) (>=0.12)

- <a name="requirement_azapi"></a> [azapi](#requirement\_azapi) (~> 2.0)

- <a name="requirement_azuread"></a> [azuread](#requirement\_azuread) (~> 3.0)

- <a name="requirement_azurerm"></a> [azurerm](#requirement\_azurerm) (~> 4.17)

- <a name="requirement_databricks"></a> [databricks](#requirement\_databricks) (~> 1.73)

- <a name="requirement_fabric"></a> [fabric](#requirement\_fabric) (~> 1.0)

- <a name="requirement_null"></a> [null](#requirement\_null) (~> 3.2)

- <a name="requirement_time"></a> [time](#requirement\_time) (~> 0.9)

## Modules

The following Modules are called:

### <a name="module_core"></a> [core](#module\_core)

Source: ./modules/core

Version:

### <a name="module_data_application"></a> [data\_application](#module\_data\_application)

Source: ./modules/dataapplication

Version:

### <a name="module_databricks_core"></a> [databricks\_core](#module\_databricks\_core)

Source: ./modules/databrickscore

Version:

### <a name="module_databricks_data_application"></a> [databricks\_data\_application](#module\_databricks\_data\_application)

Source: ./modules/databricksdataapplication

Version:

<!-- markdownlint-disable MD013 -->
<!-- markdownlint-disable MD034 -->
## Required Inputs

The following input variables are required:

### <a name="input_databricks_account_id"></a> [databricks\_account\_id](#input\_databricks\_account\_id)

Description: Specifies the databricks account id.

Type: `string`

### <a name="input_databricks_network_connectivity_config_id"></a> [databricks\_network\_connectivity\_config\_id](#input\_databricks\_network\_connectivity\_config\_id)

Description: Specifies the id of the ncc connectivity config that should be attached to the databricks workspace.

Type: `string`

### <a name="input_location"></a> [location](#input\_location)

Description: Specifies the location for all Azure resources.

Type: `string`

### <a name="input_prefix"></a> [prefix](#input\_prefix)

Description: Specifies the prefix for all resources created in this deployment.

Type: `string`

### <a name="input_subnet_ids"></a> [subnet\_ids](#input\_subnet\_ids)

Description: Specifies the resource ID of the subnets used for the Data Landing Zone.

Type:

```hcl
object({
    subnet_id_storage             = string
    subnet_id_consumption         = string
    subnet_id_engineering_private = string
    subnet_id_engineering_public  = string
    subnet_id_snowflake           = optional(string, "")
    subnet_id_fabric              = string
    subnet_id_apiserver           = optional(string, "")
    subnet_id_runtimes            = optional(string, "")
    subnet_id_aifoundry           = optional(string, "")
  })
```

## Optional Inputs

The following input variables are optional (have default values):

### <a name="input_ai_foundry_account_details"></a> [ai\_foundry\_account\_details](#input\_ai\_foundry\_account\_details)

Description: Specifies the ai foundry configuration.

Type:

```hcl
object({
    enabled = optional(bool, false)
  })
```

Default: `{}`

### <a name="input_artifactory_details"></a> [artifactory\_details](#input\_artifactory\_details)

Description: Specifies the artifactory details.

Type:

```hcl
object({
    key_vault_id                                    = optional(string, ""),
    key_vault_uri                                   = optional(string, ""),
    key_vault_secret_artifactory_pip_index_url_name = optional(string, ""),
  })
```

Default: `{}`

### <a name="input_customer_managed_key"></a> [customer\_managed\_key](#input\_customer\_managed\_key)

Description: Specifies the customer managed key configurations.

Type:

```hcl
object({
    key_vault_id                     = string,
    key_vault_key_id                 = string,
    key_vault_key_versionless_id     = string,
    user_assigned_identity_id        = string,
    user_assigned_identity_client_id = string,
  })
```

Default: `null`

### <a name="input_data_application_file_variables"></a> [data\_application\_file\_variables](#input\_data\_application\_file\_variables)

Description: If specified, provides the ability to define custom template variables used when reading in data product template files from the library path.

Type: `any`

Default: `{}`

### <a name="input_data_application_library_path"></a> [data\_application\_library\_path](#input\_data\_application\_library\_path)

Description: If specified, sets the path to a custom library folder for apllication artefacts.

Type: `string`

Default: `""`

### <a name="input_databricks_cluster_policy_file_variables"></a> [databricks\_cluster\_policy\_file\_variables](#input\_databricks\_cluster\_policy\_file\_variables)

Description: Specifies custom template variables used when reading in databricks policy template files from the library path.

Type: `any`

Default: `{}`

### <a name="input_databricks_cluster_policy_library_path"></a> [databricks\_cluster\_policy\_library\_path](#input\_databricks\_cluster\_policy\_library\_path)

Description: Specifies the databricks cluster policy library path.

Type: `string`

Default: `""`

### <a name="input_databricks_compliance_security_profile_standards"></a> [databricks\_compliance\_security\_profile\_standards](#input\_databricks\_compliance\_security\_profile\_standards)

Description: Specifies which enhanced compliance security profiles ('HIPAA', 'PCI\_DSS') should be enabled for the Azure Databricks workspace.

Type: `list(string)`

Default: `[]`

### <a name="input_databricks_force_destroy"></a> [databricks\_force\_destroy](#input\_databricks\_force\_destroy)

Description: Specifies whether databricks objects should be force destroyed.

Type: `bool`

Default: `false`

### <a name="input_databricks_permission_assignment"></a> [databricks\_permission\_assignment](#input\_databricks\_permission\_assignment)

Description: Specifies the identities that will be assigned permissions at the workspace.

Type:

```hcl
object({
    service_principals = optional(list(object({
      name = string
    })), [])
    groups = optional(list(object({
      name = string
    })), [])
  })
```

Default: `{}`

### <a name="input_databricks_unity_isolation_enabled"></a> [databricks\_unity\_isolation\_enabled](#input\_databricks\_unity\_isolation\_enabled)

Description: Specifies whether the databricks unity objects should be isolated. This only has an impact on items which are by default created with the isolation mode 'OPEN'. Other artifacts will still reside 'ISOLATED'.

Type: `bool`

Default: `false`

### <a name="input_databricks_workspace_binding_catalog"></a> [databricks\_workspace\_binding\_catalog](#input\_databricks\_workspace\_binding\_catalog)

Description: Specifies the workspace ids of the databricks workspaces to which the catalog should be connected.

Type:

```hcl
map(object({
    workspace_id = string
  }))
```

Default: `{}`

### <a name="input_environment"></a> [environment](#input\_environment)

Description: Specifies the environment of the deployment.

Type: `string`

Default: `"dev"`

### <a name="input_fabric_capacity_details"></a> [fabric\_capacity\_details](#input\_fabric\_capacity\_details)

Description: Specifies the fabric capacity configuration.

Type:

```hcl
object({
    enabled      = optional(bool, false)
    admin_emails = optional(list(string), [])
    sku          = optional(string, "F2")
  })
```

Default: `{}`

### <a name="input_fivetran_enabled"></a> [fivetran\_enabled](#input\_fivetran\_enabled)

Description: Specifies whether fivetran deployments should be enabled.

Type: `bool`

Default: `false`

### <a name="input_geo_redundancy_storage_enabled"></a> [geo\_redundancy\_storage\_enabled](#input\_geo\_redundancy\_storage\_enabled)

Description: Specifies whether geo-redundancy should be enabled for the storage layers.

Type:

```hcl
object({
    provider             = optional(bool, false)
    raw                  = optional(bool, false)
    inprogress           = optional(bool, false)
    published            = optional(bool, false)
    restricted_published = optional(bool, false)
    workspace            = optional(bool, false)
    fivetran             = optional(bool, false)
  })
```

Default: `{}`

### <a name="input_log_analytics_workspace_id"></a> [log\_analytics\_workspace\_id](#input\_log\_analytics\_workspace\_id)

Description: Specifies the resource ID of a log analytics workspace for all diagnostic logs.

Type: `string`

Default: `""`

### <a name="input_private_dns_zone_id_ai_services"></a> [private\_dns\_zone\_id\_ai\_services](#input\_private\_dns\_zone\_id\_ai\_services)

Description: Specifies the resource ID of the private DNS zone for Azure Foundry (AI Services). Not required if DNS A-records get created via Azure Policy.

Type: `string`

Default: `""`

### <a name="input_private_dns_zone_id_blob"></a> [private\_dns\_zone\_id\_blob](#input\_private\_dns\_zone\_id\_blob)

Description: Specifies the resource ID of the private DNS zone for Azure Storage blob endpoints. Not required if DNS A-records get created via Azue Policy.

Type: `string`

Default: `""`

### <a name="input_private_dns_zone_id_cognitive_account"></a> [private\_dns\_zone\_id\_cognitive\_account](#input\_private\_dns\_zone\_id\_cognitive\_account)

Description: Specifies the resource ID of the private DNS zone for Azure Cognitive Services. Not required if DNS A-records get created via Azure Policy.

Type: `string`

Default: `""`

### <a name="input_private_dns_zone_id_cosmos_sql"></a> [private\_dns\_zone\_id\_cosmos\_sql](#input\_private\_dns\_zone\_id\_cosmos\_sql)

Description: Specifies the resource ID of the private DNS zone for cosmos db sql. Not required if DNS A-records get created via Azure Policy.

Type: `string`

Default: `""`

### <a name="input_private_dns_zone_id_data_factory"></a> [private\_dns\_zone\_id\_data\_factory](#input\_private\_dns\_zone\_id\_data\_factory)

Description: Specifies the resource ID of the private DNS zone for Azure Data Factory. Not required if DNS A-records get created via Azure Policy.

Type: `string`

Default: `""`

### <a name="input_private_dns_zone_id_databricks"></a> [private\_dns\_zone\_id\_databricks](#input\_private\_dns\_zone\_id\_databricks)

Description: Specifies the resource ID of the private DNS zone for Azure Databricks UI endpoints. Not required if DNS A-records get created via Azue Policy.

Type: `string`

Default: `""`

### <a name="input_private_dns_zone_id_dfs"></a> [private\_dns\_zone\_id\_dfs](#input\_private\_dns\_zone\_id\_dfs)

Description: Specifies the resource ID of the private DNS zone for Azure Storage dfs endpoints. Not required if DNS A-records get created via Azue Policy.

Type: `string`

Default: `""`

### <a name="input_private_dns_zone_id_file"></a> [private\_dns\_zone\_id\_file](#input\_private\_dns\_zone\_id\_file)

Description: Specifies the resource ID of the private DNS zone for Azure Storage file endpoints. Not required if DNS A-records get created via Azure Policy.

Type: `string`

Default: `""`

### <a name="input_private_dns_zone_id_open_ai"></a> [private\_dns\_zone\_id\_open\_ai](#input\_private\_dns\_zone\_id\_open\_ai)

Description: Specifies the resource ID of the private DNS zone for Azure Open AI. Not required if DNS A-records get created via Azure Policy.

Type: `string`

Default: `""`

### <a name="input_private_dns_zone_id_search_service"></a> [private\_dns\_zone\_id\_search\_service](#input\_private\_dns\_zone\_id\_search\_service)

Description: Specifies the resource ID of the private DNS zone for Azure Cognitive Search endpoints. Not required if DNS A-records get created via Azure Policy.

Type: `string`

Default: `""`

### <a name="input_private_dns_zone_id_snowflake"></a> [private\_dns\_zone\_id\_snowflake](#input\_private\_dns\_zone\_id\_snowflake)

Description: Specifies the resource ID of the private DNS zone for Snowflake endpoints. Not required if DNS A-records get created via Azure Policy.

Type: `string`

Default: `""`

### <a name="input_private_dns_zone_id_vault"></a> [private\_dns\_zone\_id\_vault](#input\_private\_dns\_zone\_id\_vault)

Description: Specifies the resource ID of the private DNS zone for Azure Key Vault. Not required if DNS A-records get created via Azure Policy.

Type: `string`

Default: `""`

### <a name="input_restricted_publish_enabled"></a> [restricted\_publish\_enabled](#input\_restricted\_publish\_enabled)

Description: Specifies whether restricted publish storage layer should be enabled.

Type: `bool`

Default: `false`

### <a name="input_service_principal_name_terraform_plan"></a> [service\_principal\_name\_terraform\_plan](#input\_service\_principal\_name\_terraform\_plan)

Description: Specifies the name of the service principal used for the Terraform plan in PRs.

Type: `string`

Default: `""`

### <a name="input_snowflake_private_endpoints"></a> [snowflake\_private\_endpoints](#input\_snowflake\_private\_endpoints)

Description: Specifies the map of snowflake private endpoints to be created for this stamp.

Type:

```hcl
map(object({
    private_connection_resource_alias = string
    private_dns_a_record_name         = string
  }))
```

Default: `{}`

### <a name="input_tags"></a> [tags](#input\_tags)

Description: Specifies the tags that you want to apply to all resources.

Type: `map(string)`

Default: `{}`

### <a name="input_trusted_fabric_workspace_ids"></a> [trusted\_fabric\_workspace\_ids](#input\_trusted\_fabric\_workspace\_ids)

Description: Specifies the list of fabric workspace IDs which should be trusted to bypass storage account firewalls.

Type: `set(string)`

Default: `[]`

### <a name="input_trusted_subscription_ids"></a> [trusted\_subscription\_ids](#input\_trusted\_subscription\_ids)

Description: Specifies the list of subscription IDs which should be trusted to bypass storage account firewalls.

Type: `set(string)`

Default: `[]`

### <a name="input_zone_redundancy_enabled"></a> [zone\_redundancy\_enabled](#input\_zone\_redundancy\_enabled)

Description: Specifies whether zone-redundancy should be enabled for all resources.

Type: `bool`

Default: `true`

## Outputs

The following outputs are exported:

### <a name="output_databricks_account_id"></a> [databricks\_account\_id](#output\_databricks\_account\_id)

Description: Specifies the account id of Databricks.

### <a name="output_kubernetes_cluster_id"></a> [kubernetes\_cluster\_id](#output\_kubernetes\_cluster\_id)

Description: Specifies the id of the kubernetes cluster.

### <a name="output_storage_account_id_fivetran"></a> [storage\_account\_id\_fivetran](#output\_storage\_account\_id\_fivetran)

Description: Specifies the id of the storage account for fivetran.

### <a name="output_storage_sftp_credentials"></a> [storage\_sftp\_credentials](#output\_storage\_sftp\_credentials)

Description: Specifies the sftp credentials of the sftp ingest storage account.

<!-- markdownlint-enable -->
## License

[MIT License](/LICENSE)

## Contributing

This project accepts public contributions. Please use issues, pull requests and the discussins feature in case you have any questions or want to enhance this module.
<!-- END_TF_DOCS -->