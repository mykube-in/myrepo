# Governance Workspace Integration

This implementation creates `metadata_reader` groups and configures appropriate permissions for Governance Databricks Workspaces to access catalogs in each environment.

## Overview

The governance workspace integration automatically:
1. Creates a `metadata_reader` group at the account level (Unity Catalog metastore level)
2. Binds catalogs to the appropriate governance workspace based on environment (dev/tst/prod)
3. Grants BROWSE and USE CATALOG permissions on all catalogs
4. Grants BROWSE and USE SCHEMA permissions on all schemas (including future schemas)

## Configuration

To enable governance workspace integration, add the following variable to your terraform configuration:

```hcl
governance_workspace_ids = {
  dev  = "<workspace_id_for_fisgov-dev-eastus2-dbw001>"
  tst  = "<workspace_id_for_fisgov-tst-eastus2-dbw001>"
  prod = "<workspace_id_for_fisgov-prod-eastus2-dbw001>"
}
```

## Architecture

### Groups
- The `metadata_reader` group is created at the account level using the `databricks.account` provider
- This allows the group to be accessible across all workspaces in the same Unity Catalog metastore
- Groups are created only for the matching environment (e.g., dev group is only created when `environment = "dev"`)

### Workspace Bindings
- Catalogs are bound to the governance workspace with `BINDING_TYPE_READ_ONLY`
- Only catalogs from the same environment are bound (dev catalogs → dev governance workspace)
- This includes:
  - Engineering default catalog (e.g., `<prefix>-engnrng-default`)
  - Restricted published catalog (if enabled)
  - Data application internal catalogs
  - Data application published catalogs
  - Data application provider catalogs

### Permissions
The `metadata_reader` group receives:
- **Catalog Level**: `BROWSE`, `USE_CATALOG`
- **Schema Level**: `BROWSE`, `USE_SCHEMA` (on all schemas including future ones)

This provides read-only metadata access without granting data read permissions.

## Example Usage

```hcl
# In your terraform.tfvars or variable definitions
environment = "dev"

governance_workspace_ids = {
  dev  = "1234567890123456"  # Workspace ID for fisgov-dev-eastus2-dbw001
  tst  = ""                  # Leave empty for non-matching environments
  prod = ""                  # Leave empty for non-matching environments
}
```

## Files Modified

- `modules/databrickscore/governance_workspaces.tf` - Core catalog governance configuration
- `modules/databrickscore/variables.tf` - Added `governance_workspace_ids` variable
- `modules/databricksdataapplication/governance_workspaces.tf` - Data application catalog governance configuration
- `modules/databricksdataapplication/variables.tf` - Added `governance_workspace_ids` and `governance_metadata_reader_group_names` variables
- `variables.tf` - Root level governance workspace variable
- `databricks.tf` - Pass governance variables to submodules

## Notes

- The implementation is environment-aware and only creates resources for the matching environment
- Workspace bindings are only created when the corresponding workspace ID is provided (non-empty)
- The `metadata_reader` group name is configurable through `governance_metadata_reader_group_names` variable
- All schema grants use `databricks_grants` resource which applies to all schemas including future ones
